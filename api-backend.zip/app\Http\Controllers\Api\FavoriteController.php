<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Property;
use Illuminate\Http\Request;

class FavoriteController extends Controller
{
    public function index(Request $request)
    {
        $favorites = $request->user()
            ->favorites()
            ->with('property.type', 'property.city')
            ->get();

        return response()->json([
            'favorites' => $favorites,
        ]);
    }

    public function store(Request $request, Property $property)
    {
        $favorite = $request->user()->favorites()->firstOrCreate([
            'property_id' => $property->id,
        ]);

        return response()->json([
            'message' => 'Property added to favorites.',
            'favorite' => $favorite,
        ], 201);
    }

    public function destroy(Request $request, Property $property)
    {
        $request->user()->favorites()->where('property_id', $property->id)->delete();

        return response()->json([
            'message' => 'Property removed from favorites.',
        ]);
    }
}
